const mongoose = require("mongoose");


const RoomSchema = new mongoose.Schema(
  {
    facility:   { type: mongoose.Schema.Types.ObjectId, ref: "Facility", required: true },
    _id: { type: mongoose.Schema.Types.ObjectId, auto: true }, // ← unique per room
    roomNumber:  String,              // “101A”
    group:       String,              // “A” or “B”
    notes:       String,
  },
  { _id: false }
);
module.exports = mongoose.model("Room", RoomSchema);
